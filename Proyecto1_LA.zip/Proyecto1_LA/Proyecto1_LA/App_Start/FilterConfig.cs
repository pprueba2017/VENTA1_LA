﻿using System.Web;
using System.Web.Mvc;

namespace Proyecto1_LA
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
